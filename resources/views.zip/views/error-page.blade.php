@extends('layouts.master') @section('content')
<div id="MediaForm">
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Oops! That page can’t be found.</h3>
            </div>
            <div class="panel-body ierekpanel-b">
                we update our links to be more friendly to our users if you come from old link please use the main menu to navigate inside the site you can use the search or have a look on our.
            </div>
        </div>
    </div>
</div>
@endsection
