@extends('admin.layouts.master')

@section('content')
	{{ 'Manage Conferences' }}
@endsection