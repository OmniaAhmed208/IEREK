@extends('layouts.master')
@section('content')
<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Page cannot be found</h3>
        </div>
        <div class="panel-body ierekpanel-b" >
            <div class="framed-content">
            <center><h1>Page cannot be found:</h1></center>
            <p>We are updating our links to be more friendly to our users, if you are using an old link please use the main menu to navigate inside the site. You can use the search or have a look on our sitemap.</p>
            </div>
        </div>
    </div>
</div>
@endsection