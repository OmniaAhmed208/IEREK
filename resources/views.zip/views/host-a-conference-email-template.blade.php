@extends('layouts.master')
@section('content')

<div class="container ">
    <div class="col-md-12">
    <div class="row mr-top">
        <div class="email-title-bg">
            <p class="font"> Host A Conference Email </p>
        </div>
        <div class="col-md-12 email-wrapper">
            <table border="1" >
                <tr>
                    <td class="cell-title">
                        University name
                    </td>
                    <td>
                        lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                    </td>
                </tr>

                <tr>
                    <td class="cell-title">
                        Contact person name
                    </td>
                    <td>
                        lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                    </td>
                </tr>

                <tr>
                    <td class="cell-title">
                        Contact person email
                    </td>
                    <td>
                        lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                    </td>
                </tr>

                <tr>
                    <td class="cell-title">
                        Contact person affiliation
                    </td>
                    <td>
                        lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                    </td>
                </tr>


            </table>
            <table border="1">

                <td>
                    lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                </td>

            </table>

            <table border="1">

                <td>
                    lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                </td>

            </table>
            <table border="1">

                <td>
                    lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                </td>

            </table>
            <table border="1">

                <td>
                    lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                </td>

            </table> <table border="1">

                <td>
                    lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                </td>

            </table>
            <table border="1">

                <td>
                    lorem ipsum lorem ipsum lorem ipsum lorem ipsum lorem ipsum
                </td>

            </table>

        </div>
        </div>
    </div>
</div>
@endsection
