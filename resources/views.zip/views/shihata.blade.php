@extends('layouts.master') @section('content')

{{ $description}}
<br>
My First name : {{ $firstName}}
<br>
My Last name  {{ $lastName}}
<br>
My Age  {{ $myAge}}


@endsection