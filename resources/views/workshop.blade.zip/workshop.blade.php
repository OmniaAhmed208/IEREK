@extends('layouts.master') @section('content')
<title>
    {{$event->title_en}}
</title>
<div id="CONDETAILP">
    <div class="container">
        <figure class="cover-img">
            @if(file_exists('storage/uploads/workshops/'.$event->event_id.'/cover_img.jpg'))<img src="/storage/uploads/workshops/{{ $event->event_id }}/cover_img.jpg" class="img-responsive" alt="" />@endif
        </figure>
        <div class="row">
            <div class="col-md-3 hidden-sm hidden-xs">
                <div id="bs-example-navbar-collapse-3" class="navbar-collapse collapse ">
                    <div class="quick-links" style="margin-bottom:10px;">
                        <div class="frame-title blue-title">Quick Links</div>
                        <ul id="menu-quick-links" class="menu">
                            <li id="menu-item-4028" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4028">
                                <a href="#">Become a speaker</a>
                            </li>
                            <li id="menu-item-4029" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4029">
                                <a href="#">Become a sponsor</a>
                            </li>
                            <li id="menu-item-4684" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4684">
                                <a href="#">Media Coverage Request</a>
                            </li>
                            <li id="menu-item-4030" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4030">
                                <a href="#">Scientists Forum</a>
                            </li>
                            <li id="menu-item-40311" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4030"><a href="https://www.ierek.com/newierek/fullfront/terms.php">Terms & Conditions</a></li>
                        </ul>
                    </div>
                    <div class="quick-links">
                        <div class="frame-title">Navigation</div>
                        <ul class="additional-menu">
                        @foreach($sections as $section)
                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4030">
                                <a href="#section{{ $section->section_id }}" class="navx" onclick="showSection('{{ $section->section_id }}')" id="nav{{ $section->section_id }}" style="<?php if($section->section_type_id == 1){echo 'background:#f9f9f9';} ?>" >{{ $section->title_en }}</a>
                            </li>
                        @endforeach
                        </ul>
                    </div>
                    <div class="plain-box">
                        <a href="#Scientific Committee" class="event-navigation" onclick="change_sce({{$event->event_id}})">
                            <img src="/uploads/images/NEW.jpg" style="width:100%; "> </a>
                    </div>
                </div>
                <div class="hidden-xs hidden-sm">
                    <div class="styled-box">
                        <div class="box-title">
                            Guest Editors
                        </div>
                        <div class="box-content">
                            <div class="chairman-item">
                                <p style="white-space:pre-wrap"><strong>Professor Francesco Calabrò</strong>, Professor of Real Estate Appraisal and Economic Assessment of Plans. PAU Dept. Mediterranea University of Reggio Calabria.
                                    <strong>Professor Lucia Della Spina</strong>, Aggregate Professor in Appraisal at the Heritage and Architecture. PAU Dept. Mediterranea University of Reggio Calabria.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="styled-box">
                        <div class="box-title">
                            Contact
                        </div>
                        <div class="box-content">
                            <p style="white-space:pre-wrap"><strong>Mahmoud mustafa</strong> nmp@ierek.com +2 03 5763827 +20 1013001198 01026604949
                            </p>
                        </div>
                    </div>
                </div>
                <div class="plain-box hidden-sm hidden-xs">
                    <a href="https://www.ierek.com/calendar/"> <img style="width: 100%" src="https://www.ierek.com/wp-content/uploads/2014/08/Events.jpg"> </a>
                </div>
            </div>
            <div class="col-md-9 padle " style="position: static; ">
                <div class="framed-box">
                    <div class="frame-title">
                        {{ $event->title_en }}
                    </div>
                    <div class="framed-content">
                        <div class="styled-box">
                            <div class="box-content row">
                                <div class="col-md-3 hidden-xs hidden-sm">
                                    <div class="conference-cover">
                                        @if(file_exists('storage/uploads/workshops/'.$event->event_id.'/slider_img.jpg')) <img style="width: 100%; max-height: 218px;" src="/storage/uploads/workshops/{{ $event->event_id }}/slider_img.jpg"> @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    
                                    <h2 class="box-title">
                                    <!--    Call For Paper -->
                                    </h2>
                                    
                                    <div class="workshop-data">
                                        <ul>
                                            <li>
                                                {{ date("d, M", strtotime($event->start_date)) }} / {{ date("d, M Y", strtotime($event->end_date)) }}
                                            </li>
                                            <li><b>{{ $event->location_en }}</b></li>
                                        </ul>
                                        <div class="addthis_sharing_toolbox" style="text-align: center;margin-top: 15px;"></div><span class="workshop-email">
                                            Workshop Email
                                            <br> 
                                            <a href="mailto:{{ $event->email }}">{{ $event->email }}</a>
                                        </span></div>
                                </div>
                                <div class="col-md-3">
                                    <center>
                                        @if(file_exists('storage/uploads/workshops/'.$event->event_id.'/featured_img.jpg')) <img src="/storage/uploads/workshops/{{ $event->event_id }}/featured_img.jpg" alt="" style="max-width: 100%;  max-height: 232px;" class="hidden-xs hidden-sm" align="center"> @endif
                                    </center>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- <p class="bg-success message">
                        
                    </p> -->

                    <div class="styled-box">
                        <div class="box-content">
                            </a>
                            @if((Auth::check()))
                                @if($isreg == 1)
                                    <a href="{{ url('/payment/'.$event->slug) }}" id="regconf" style="" class="popup-register workshop-registration-btn">Fees<span class="hidden-xs">Payment</span> </a>
                                @else
                                    <a href="javascript:void(0);" id="regconf" style="" class="popup-register workshop-registration-btn" onclick="conf_register({{ $event->event_id }})">Register<span class="hidden-xs">For Audience</span> </a>
                                @endif
                            @else
                            <a href="javascript:void(0);" id="regconf" style="" class="popup-register workshop-registration-btn" onclick="display_log(0)">Login<span class="hidden-xs">To Register</span> </a>
                            @endif

<!--
                            @if((Auth::check()))
                                @if($isreg == 1)
                                    <a href="{{ url('/abstract/'.$event->slug) }}" class="workshop-registration-btn pull-right">Submit an Abstract<span class="hidden-xs">For Authors</span> </a>
                                @else
                                    <a href="javascript:void(0);" onclick="conf_register({{ $event->event_id }})" class="workshop-registration-btn pull-right">Register<span class="hidden-xs">To Submit an Abstract</span> </a>
                                @endif
                            @else
                                <a href="javascript:void(0);" onclick="display_log(0)" class="workshop-registration-btn pull-right">Login<span class="hidden-xs">To Submit an Abstract</span> </a>
                            @endif  

-->

                        </div>
                    </div>
                    <button type="button" class="navbar-toggle collapsed buttonx hidden-md hidden-lg" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false" style="margin-right: 0px !important;     border-radius: 0px;">
                        Quick Links & More Details <i class="fa fa-caret-down" style="background: #0C3852; margin-top: 0px !important; font-weight: 600; font-size: large; width: 9%; float: right;    padding: 4px; color: red;"></i>
                    </button>
                    <div class="hidden-md hidden-lg">
                        <div id="bs-example-navbar-collapse-2" class="navbar-collapse collapse">
                            <div class="quick-links" style="margin-bottom:10px;">
                                <div class="frame-title blue-title">
                                    Quick Links
                                </div>
                                <ul id="menu-quick-links" class="menu">
                                    <li id="menu-item-40311" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4030"><a href="https://www.ierek.com/newierek/fullfront/terms.php">Terms & Conditions</a></li>
                                </ul>
                            </div>
                            <div class="quick-links">
                                <div class="frame-title">
                                    Navigation
                                </div>
                                <ul class="additional-menu">
                                    @foreach($sections as $section)
                                        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4030">
                                            <a href="#section{{ $section->section_id }}" class="navs" onclick="showSection('{{ $section->section_id }}')" id="navs{{ $section->section_id }}" <?php if($section->section_type_id == 1){echo 'style="background:#f9f9f9"';} ?>>{{ $section->title_en }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                            <div class="plain-box">
                                <a href="#Scientific Committee" class="event-navigation" onclick="change_section({{ $section->section_id }})">
                                    <img src="/uploads/images/NEW.jpg" style="width:100%; "> </a>
                            </div>
                        </div>
                    </div>
                    @foreach($sections as $section)
                    <div class="styled-box section" <?php if($section->section_type_id != 1){echo 'style="display:none';} ?>" id="section{{ $section->section_id }}">
                        <div class="box-title">
                            {{ $section->title_en }}
                        </div>
                        <div class="box-content">
                            <section>
                            @if($section->section_type_id == 2)
                                @if(isset($topics) && count($topics) > 0)
                                    @foreach($topics as $topic)
                                    <div class="topic-title">{{ $topic->position.'. '.$topic->title_en }}</div>
                                    <?php if(strlen($topic->description_en) > 11){echo '<div class="col-md-12" style="margin-bottom:5px;margin-top:5px;"><div class="topic-description" style="width:98%;float:right"><p style="text-align: justify;text-justify: inter-word;">'; echo $topic->description_en; echo '</p></div></div>';} ?>
                                    @endforeach
                                @endif
                            @elseif($section->section_type_id == 6)
                                @if(isset($dates) && count($dates) > 0)
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Date</th>
                                            <th>Notes</th>
                                        </tr>
                                    </thead>
                                    <tbody>                                
                                        @foreach($dates as $date)
                                            @if($date->to_date != '0000-00-00 00:00:00')
                                                <tr>
                                                    <td>{{ $date->title }}</td>
                                                    <td>{{ date("jS F Y", strtotime($date->to_date) ) }}</td>
                                                    <td>{{ $date->title_en }}</td>
                                                </tr>
                                            @endif
                                        @endforeach
                                    </tbody>
                                </table>
                                @endif
                            @elseif($section->section_type_id == 3)
                                @if(isset($fees) && count($fees) > 0)
                                    <table class="table table-bordered table-hover">
                                        <tbody>                                
                                            @foreach($fees as $fee)
                                                @if($fee->deleted != 1)
                                                    <tr>
                                                        <td>{{ $fee->title_en }}</td>
                                                        <td>{{$event->currency.' '}}{{ $fee->amount }}</td>
                                                    </tr>
                                                @endif
                                            @endforeach
                                        </tbody>
                                    </table>
                                @endif
                            @else
                            <?php if($section->section_type_id == 7 && file_exists('storage/uploads/workshops/'.$event->event_id.'/featured_img.jpg')){echo '<img src="/storage/uploads/workshops/'.$event->event_id.'/featured_img.jpg" class="procedia-right">';} echo $section->description_en; ?>
                            @endif
                            </section>
                        </div>
                    </div>
                    @endforeach
                    <div class="styled-box first-tab-only" style="height:355px;">
                        <div class="box-title">
                            Featured Workshops
                        </div>
                        <div class="box-content">
                            @foreach($featured as $conf)
                            <div class="col-md-6">
                                <div class="workshops-list-item" style="height:300px;">
                                    <a href="{{ url('events/') }}{{ '/'.$conf->slug }}">
                                        <div class="workshop-item-cover" style="width:100%;height:150px;background: url({{ url('/storage/uploads/workshops/'.$conf->event_id.'/cover_img.jpg')}}) no-repeat center center; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover; ">
                                        </div>
                                        <div class="conference-item-title">
                                            {{$conf->title_en}}
                                        </div>
                                        <div class="conference-item-location">
                                            {{$conf->location_en}}
                                        </div>
                                        <div class="conference-item-detail">
                                            {{date("d M Y", strtotime($conf->start_date))}}
                                        </div>
                                    </a>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="framed-box hidden-lg hidden-md">
                    <div class="framed-content">
                        <div class="styled-box">
                            <div class="box-title">
                                Guest Editors (Arts)
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                        <div class="styled-box">
                            <div class="box-title">
                                Guest Editors
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                        <div class="styled-box">
                            <div class="box-title">
                                Chairman Editor
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                        <div class="styled-box">
                            <div class="box-title">
                                Honorary Chairman
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                        <div class="styled-box">
                            <div class="box-title">
                                Guest Editors (Architecture)
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                        <div class="styled-box">
                            <div class="box-title">
                                Honorary Chairperson
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                        <div class="styled-box">
                            <div class="box-title">
                                Chairperson
                            </div>
                            <div class="box-content">
                                <div class="chairman-item">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
<script type="text/javascript">
    function showSection(id)
    {
        $('.section').each(function(){
            $(this).slideUp(200);
        });
        $('.navx').each(function(){
            $(this).css('background','#fff');
        });
        $('#nav'+id).css('background','#f9f9f9');
        $('.navs').each(function(){
            $(this).css('background','#fff');
        });
        $('#navs'+id).css('background','#f1f1f1');
        $('#section'+id).slideDown(200);
        setTimeout(function(){window.open('#section'+id, '_self')}, 200);
    }

        $(document).ready(function(){
            var current = window.location.hash;
            current = current.replace('#section','');
            showSection(current);
    @if((Auth::check()))
        @if($isreg == 1)
            confirmX('<strong>Dear Colleague</strong>,<br>You have successfully registered in Workshop: <b>{{$event->title_en}}</b>, please confirm your registration as you should pay the required fees to be confirmed.','{{ url('/payment/'.$event->slug) }}', 'Payment', 'Postpone');
        @endif
    @endif

        });
</script>
@endpush
